#!/usr/bin/env python

def read_tau_eff(type='MW',uv_bump=1.0,PAH=1.0,mach=1.0,source_radius=0.5,tauv_h=1.0):
   from astropy.io import fits
   import numpy as np
   """Give an effective optical depth as a function of wavelength (micron) for various model parameters.
      (2025.12.16)
   Returns:
       wavelength, tau_eff
   """
   HOME_DIR = '.'

   print('>>> Available Model Parameters <<<')
   print('')
   print("   type          = 'MW', 'MW_witt', 'LMC', 'SMC', 'SMC_witt'")
   print("      if type == 'MW':")
   print('         uv_bump = 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0')
   print('         PAH     = 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0')
   print('         either uv_bump or PAH are required.')
   print("      else:")
   print('         uv_bump and PAH parameters are ignored.')
   print('   mach          = 0, 1, 2, 4, 6, 8, 10, 12, 16, 20')
   print('   source_radius = 0.0, 0.2, 0.4, 0.6, 0.8, 0.9, 1.0')
   print('   tauv_h        = 0.1, 0.5, 1.0, 2.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0')

   match type:
      case 'MW':
           fname = 'MW'
           if uv_bump < 1.0 and uv_bump >= 0.0:
              fname = '%s_BUMP0%d' % (fname, uv_bump*10.0)
           elif PAH < 1.0 and PAH >= 0.0:
              fname = '%s_PAH0%d' % (fname, PAH*10.0)
      case 'MW_witt':
           fname = 'MW_witt'
      case 'SMC':
           fname = 'SMC'
      case 'SMC_witt':
           fname = 'SMC_witt'
      case 'LMC':
           fname = 'LMC'
      case _:
           fname = 'MW'
   fname = fname + '.fits.gz'
   a     = fits.open(HOME_DIR+'/data/'+fname)

   # arrays for model parameters
   # mach, source_radius, tauv_h
   mach_arr   = a[1].data['mach'][0]
   radius_arr = a[1].data['radius'][0]
   tauv_h_arr = a[1].data['tauv_h'][0]
   # wavelength array
   wavl     = a[1].data['wavl'][0]
   # Av, E(B-V), A(lambda), tau_eff(lambda) for each models.
   Av       = a[1].data['Av'][0]
   EB_V     = a[1].data['EBV'][0]
   A_lambda = a[1].data['alambda'][0]
   tau_eff  = a[1].data['taueff'][0]

   wavl     = np.flip(wavl)
   A_lambda = np.flip(A_lambda,axis=3)
   tau_eff  = np.flip(tau_eff,axis=3)

   # im, ir, it
   im = np.abs(mach_arr   - mach).argmin()
   ir = np.abs(radius_arr - source_radius).argmin()
   it = np.abs(tauv_h_arr - tauv_h).argmin()

   print('')
   print('>>> Attenuation Curve for the following parameters will be return:')
   print('    mach   = ', mach_arr[im])
   print('    source_radius = ', radius_arr[ir])
   print('    tauv_h = ', tauv_h_arr[it])

   return wavl,tau_eff[im][ir][it]
